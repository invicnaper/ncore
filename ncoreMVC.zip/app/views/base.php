<?php
/*
 *        NcoreMVC
 *  @file : base views
 *  @Author : Hamza Bourrahim and Quentin Jeanneaud
*/

namespace views{

  class baseView{

      public static $template = "/";

  }

}
