<?php
/*
 *        NcoreMVC
 *  @file : testController
 *  @Author : Hamza Bourrahim and Quentin Jeanneaud
*/

class itemsFeaturedController {

  public function index(){
      /* calling model  */
      $name = itemsFeatured::getData("item1","name");

      echo $name;
  }

}
