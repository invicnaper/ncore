<?php
/*
 *        NcoreMVC
 *  @file : ncore.php | configuration file
 *  @Author : Hamza Bourrahim
*/

return array(

      "DEBUG" => "false",

      /* lang */
      "LOCALE" => "en"

);
