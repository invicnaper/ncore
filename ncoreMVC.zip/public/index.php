<?php
/*
 *        NcoreMVC
 *  @file : index.php
 *  @Author : Hamza Bourrahim and Quentin Jeanneaud
*/


/*
 *  autload everything
 *
*/
require __DIR__.'/../bootstrap/autoload.php';
